<style lang="scss">
.hqs-popup {
	.top-radius {
		border-radius: 10px 10px 0 0;
	}
	.qs-header {
		display: flex;
		align-items: center;
		justify-content: space-between;
		position: relative;
	}
	.qs-title {
		font-size: 16px;
		font-weight: bold;
	}
	.hidden { visibility: hidden; }
	.qs-side {
		min-width: 60px;
		padding: 15px;
		color: #999;
		&:active { opacity: .8; }
	}
	.ta-r { text-align: right; }
	.bg-white { background: white; }
}
</style>

<template>
<uni-popup ref="popup" 
	:mask-click="maskClick" @change="onChange"
	:type="from" class="hqs-popup">
	<view class="bg-white" :class="{ 'top-radius': from == 'bottom' }"
		:style="panStyle" 
		@touchstart="onTouch" @touchmove="onTouch" @touchend="onTouch">
		<block v-if="from == 'bottom'">
			<view>
				<view class="qs-header">
					<view class="qs-side" :class="{'hidden': !showBack}"
						@click="onBack">
						<slot name="back">
							<text>返回</text>
						</slot>
					</view>
					<slot name="title">
						<text class="qs-title">{{ title }}</text>
					</slot>
					<view class="qs-side ta-r" :class="{'hidden': !showClose}"
						@click="close">
						<slot name="close">
							<text>关闭</text>
						</slot>
					</view>
				</view>
				<scroll-view scroll-y="true" :style="{ 'height': height }"
					@scroll="onScroll">
					<view>
						<slot></slot>
					</view>
				</scroll-view>
			</view>
		</block>
		<block v-else>
			<slot></slot>
		</block>
	</view>
</uni-popup>
</template>

<script>
export default {
	props: {
		// 弹窗显示可通过v-model控制
		value: Boolean,

		// 弹窗打开开始方向
		from: {
			type: String,
			default: 'bottom',
		},
		
		// 弹窗内容高度
		height: {
			type: String,
			default: '50vh',
		},

		// 弹窗标题
		title: String,

		// 是否显示返回按钮
		showBack: Boolean,

		// 是否显示关闭按钮
		showClose: {
			type: Boolean,
			default: true,
		},

		// 是否可点击模态背景关闭弹窗
		maskClick: {
			type: Boolean,
			default: true,
		},
	},
	data() {
		return {
			scrollTop: 0,
			panStyle: '',
			showPopup: false,
		}
	},
	watch: {
		value(val) {
			if(val == this.showPopup) return
			if(val) this.open()
			else this.close()
		},
		showPopup(val) {
			this.$emit('input', val)
		},
	},
	mounted() {
		if(this.value) this.open()
	},
	methods: {
		onScroll(e) {
			this.scrollTop = e.detail.scrollTop
		},
		onTouch(ev) {
			// if(!this.maskClick) return
			const { pageX, pageY } = ev.changedTouches[0] || {}
			if(ev.type == 'touchstart') {
				this.startX = pageX
				this.startY = pageY
				this.startTime = ev.timeStamp
			} else {
				const orien = this.from == 'bottom' ? 'Y' : 'X'
				let moveDis = pageY - this.startY
				if(this.from == 'left') moveDis = this.startX - pageX
				else if(this.from == 'right') moveDis = pageX - this.startX
				if(!this.maskClick) moveDis /= 3
				const duration = (ev.timeStamp - this.startTime)
				const speed = moveDis/duration
				if(ev.type == 'touchend') {
					if(this.panStyle) {
						if(this.maskClick && (moveDis > 120 || speed > 0.25)) {
							this.close()
						}
						else {
							this.panStyle = `transform: translate${orien}(0); transition: all ease 200ms`
						}
						setTimeout(() => {
							this.panStyle = ''
						}, 300)
					}
					// conScrollTop = 0
					return
				}
				// if(this.scrollTop > 0) return
				
				if(moveDis > 0) {
					if(this.from == 'left') moveDis *= -1
					this.panStyle = `transform: translate${orien}(${moveDis}px); transition: none;`
				}
			}
		},
		onChange({ show }) {
			this.showPopup = show
		},
		open() {
			this.$refs.popup.open()
			this.showPopup = true
		},
		close() {
			this.$refs.popup.close()
			this.showPopup = false
		},
		onBack() {
			this.$emit('back')
		},
	}
}
</script>
